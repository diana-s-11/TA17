from selenium import webdriver
from time import sleep

from selenium.webdriver.common.by import By

name = "Diana"
bday = "07/07/2003"
hour = "9:15"
country = "Romania"
city = "Bucuresti (Bucharest), Bucuresti"


url = "https://www.mybodygraph.com/"
driver = webdriver.Chrome()

driver.get(url)
driver.maximize_window()

driver.find_element(By.XPATH, "/html/body/div/div[5]/div[2]/div[2]/div/div[1]/div/div/div[1]/a").click()
sleep(2)
driver.find_element(By.XPATH, "/html/body/div[1]/div[5]/div[2]/div/div[2]/div/div[1]/div/button").click()
sleep(2)
driver.find_element(By.XPATH, "/html/body/div[3]/div/div/div[3]/fieldset/div[1]/div/input").send_keys(name)
sleep(2)
driver.find_element(By.XPATH, "/html/body/div[3]/div/div/div[3]/fieldset/div[2]/div[1]/div/div/input").send_keys(bday)
sleep(2)
driver.find_element(By.XPATH, "/html/body/div[3]/div/div/div[3]/fieldset/div[2]/div[2]/div/input").send_keys(hour)
sleep(2)
driver.find_element(By.XPATH, "/html/body/div[3]/div/div/div[3]/fieldset/div[4]/div/input").send_keys(country)
sleep(2)
driver.find_element(By.XPATH, "/html/body/div[3]/div/div/div[3]/fieldset/div[5]/div/input").send_keys(city)
sleep(2)
driver.find_element(By.XPATH, "/html/body/div[3]/div/div/div[4]/button[2]/span").click()
sleep(20)
driver.find_element(By.XPATH, "/html/body/div[1]/div[5]/div[2]/div/div[2]/div/div[2]/table/tbody/tr[6]/td/dfn").click()
sleep(5)
driver.find_element(By.XPATH, "/html/body/div[1]/div[5]/div[2]/div/div[2]/div[2]/div/div/div[2]/dfn[2]").click()
sleep(5)
driver.find_element(By.XPATH, "/html/body/div[1]/div[5]/div[2]/div/div[2]/div[3]/div/div/div[1]/button").click()
sleep(5)


#shop & items

driver.find_element(By.XPATH, "/html/body/div/div[3]/nav/div[2]/div/ul/li[5]/a").click()
sleep(4)
driver.find_element(By.XPATH, "/html/body/div/div[5]/div[2]/div/ul/li[2]/a/img").click()
sleep(5)

